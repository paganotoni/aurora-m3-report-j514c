aurora-sep --m3-report (aurora-2026.10.17.20), 2026-11-06T13:21:59Z
Read-only. The host name is replaced by "host", user names by "user", serial numbers by
SERIAL and MAC addresses by xx:xx:xx:xx:xx:xx; kernel log lines naming a USB serial are left out.
  system.txt        who this Mac is, its boot loader, kernel, command line and packages
  dt-nodes.txt      every device-tree node: path, compatible, status
  drivers.txt       devices with and without a driver, deferred probes, power domains, modules
  kernel-log.txt    this boot's whole kernel log
  dmesg-m3.txt      the kernel log lines of the M3 bring-up
  smc-keys.txt      the SMC's temperature (T*, mC) and power (P*, mW) keys
  cpu.txt           CPU topology, cpufreq policies, cpuidle, cpuinfo
  buses.txt         lspci -nnk, lsusb, lsusb -t
  typec.txt         USB-C ports, partners and alternate modes
  display.txt       DRM connectors and modes, backlight
  power.txt         power supplies, thermal zones, cooling devices, hwmon
  sound-input.txt   sound cards and input devices
  network.txt       network interfaces and their drivers, Bluetooth, rfkill
  reserved-memory.txt  the reserved-memory nodes (name, compatible, label, reg, status), and
                    whether the boot loader's adt and m1n1_stage2.log nodes are there
  boot-dt.txt       which device tree this Mac boots: model, compatible, the /chosen asahi,*
                    entries, the stub's version, the device trees in boot.bin
  adt-allowlist.txt the ADT reader's allowlist of the boot loader's ADT (on an M3), or why
                    there is none
  adt-check.txt     the ADT read's steps, and the MTD devices and phram's state before and after
  m1n1-stage2-log.txt  m1n1's log of this boot, read with the ADT (lines naming serial numbers,
                    UUIDs other than firmware images' and the like left out), or why there is none
  m1n1-stage2-log.raw  the same log region whole (16 KiB), those lines overwritten with x
  interrupts.txt    /proc/interrupts
  iomem.txt         /proc/iomem, its System RAM and reserved ranges only
  usb-display.txt   USB tree, USB-C roles and DRM connector states (as in earlier reports)
  chosen/           the boot loader's /chosen entries for the M3 chips
